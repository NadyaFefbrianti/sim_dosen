<?php
// dosen.php - daftar dosen: cari, filter, paginasi, hapus
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/dosen_model.php';
require_perm('dosen.read');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_perm('dosen.write');
    csrf_verify();
    if (($_POST['action'] ?? '') === 'delete') {
        dosen_delete((int)($_POST['id'] ?? 0));
        flash_set('success', 'Data dosen dihapus.');
    }
    redirect('dosen.php');
}

$f = dosen_filters($_GET);
$perPage = 10;
$total = dosen_count($f);
$pages = max(1, (int)ceil($total / $perPage));
$page = min(max(1, (int)($_GET['page'] ?? 1)), $pages);
$rows = dosen_list($f, $perPage, ($page - 1) * $perPage);
$canWrite = can('dosen.write');
$qs = fn(array $over) => http_build_query(array_filter(array_merge($_GET, $over), fn($v) => $v !== '' && $v !== null));

$pageTitle = 'Data Dosen';
$active = 'dosen';
include __DIR__ . '/includes/header.php';
?>
<div class="pagehead">
  <h1>Data Dosen</h1>
  <?php if ($canWrite): ?><a class="btn" href="dosen_form.php">Tambah dosen</a><?php endif; ?>
</div>

<form method="get" class="card filters">
  <div class="field"><label for="q">Cari nama / NIP / NUPTK / no. registrasi</label>
    <input type="search" id="q" name="q" value="<?= e($_GET['q'] ?? '') ?>"></div>
  <div class="field"><label for="prodi_id">Program studi</label>
    <select id="prodi_id" name="prodi_id"><option value="">Semua</option>
      <?php foreach (options('program_studi') as $id => $n): ?><option value="<?= $id ?>" <?= (int)($_GET['prodi_id'] ?? 0) === $id ? 'selected' : '' ?>><?= e($n) ?></option><?php endforeach; ?>
    </select></div>
  <div class="field"><label for="status_aktivitas_id">Status aktivitas</label>
    <select id="status_aktivitas_id" name="status_aktivitas_id"><option value="">Semua</option>
      <?php foreach (options('status_aktivitas') as $id => $n): ?><option value="<?= $id ?>" <?= (int)($_GET['status_aktivitas_id'] ?? 0) === $id ? 'selected' : '' ?>><?= e($n) ?></option><?php endforeach; ?>
    </select></div>
  <div class="field"><label for="status_serdos">Status serdos</label>
    <select id="status_serdos" name="status_serdos"><option value="">Semua</option>
      <?php foreach (['Sudah', 'Belum'] as $s): ?><option <?= ($_GET['status_serdos'] ?? '') === $s ? 'selected' : '' ?>><?= $s ?></option><?php endforeach; ?>
    </select></div>
  <div class="actions"><button class="btn" type="submit">Terapkan</button><a class="btn btn-line" href="dosen.php">Reset</a></div>
</form>

<div class="card">
  <p class="muted"><?= $total ?> dosen ditemukan.</p>
  <div class="tablewrap"><table>
    <thead><tr>
      <th>No</th><th>Nomor Registrasi</th><th>NUPTK</th><th>Nama</th><th>NIP</th><th>Jabatan Fungsional</th><th>Kepangkatan</th>
      <th>Pendidikan Terakhir</th><th>Rumpun Ilmu</th><th>Status Serdos</th><th>Status Pegawai</th><th>Ikatan Kerja</th>
      <th>Status Aktivitas</th><th>Penempatan</th><?php if ($canWrite): ?><th>Aksi</th><?php endif; ?>
    </tr></thead>
    <tbody>
    <?php foreach ($rows as $i => $d): ?>
      <tr>
        <td><?= ($page - 1) * $perPage + $i + 1 ?></td>
        <td class="nowrap"><?= e($d['nomor_registrasi']) ?></td>
        <td><?= e($d['nuptk'] ?? '-') ?></td>
        <td><?= e($d['nama']) ?></td>
        <td><?= e($d['nip'] ?? '-') ?></td>
        <td><?= e($d['jabatan_fungsional'] ?? '-') ?></td>
        <td><?= e($d['kepangkatan'] ?? '-') ?></td>
        <td><?= e($d['pendidikan'] ?? '-') ?></td>
        <td><?= e($d['rumpun_ilmu'] ?? '-') ?></td>
        <td><span class="badge <?= $d['status_serdos'] === 'Sudah' ? '' : 'badge-no' ?>"><?= e($d['status_serdos']) ?></span></td>
        <td><?= e($d['status_pegawai'] ?? '-') ?></td>
        <td><?= e($d['ikatan_kerja'] ?? '-') ?></td>
        <td><?= e($d['status_aktivitas'] ?? '-') ?></td>
        <td><?= e($d['penempatan'] ?? '-') ?></td>
        <?php if ($canWrite): ?>
        <td class="nowrap"><div class="actions">
          <a class="btn btn-sm btn-line" href="dosen_form.php?id=<?= (int)$d['id'] ?>">Ubah</a>
          <form method="post" onsubmit="return confirm('Hapus data dosen ini?');">
            <?= csrf_field() ?><input type="hidden" name="action" value="delete"><input type="hidden" name="id" value="<?= (int)$d['id'] ?>">
            <button class="btn btn-sm btn-danger" type="submit">Hapus</button>
          </form></div></td>
        <?php endif; ?>
      </tr>
    <?php endforeach; ?>
    <?php if (!$rows): ?><tr><td colspan="15" class="muted">Tidak ada data yang cocok.</td></tr><?php endif; ?>
    </tbody>
  </table></div>

  <?php if ($pages > 1): ?>
  <nav class="pager" aria-label="Halaman">
    <?php for ($p = 1; $p <= $pages; $p++): ?>
      <?php if ($p === $page): ?><span class="cur"><?= $p ?></span>
      <?php else: ?><a href="?<?= e($qs(['page' => $p])) ?>"><?= $p ?></a><?php endif; ?>
    <?php endfor; ?>
  </nav>
  <?php endif; ?>
</div>
<?php include __DIR__ . '/includes/footer.php'; ?>
