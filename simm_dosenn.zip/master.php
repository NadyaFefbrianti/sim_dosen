<?php
// master.php - CRUD semua tabel master (universitas, fakultas, prodi, jabatan, dst)
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/master_model.php';
require_perm('master.read');

$tables = master_tables();
$t = $_POST['t'] ?? $_GET['t'] ?? 'program_studi';
if (!is_string($t) || !isset($tables[$t])) $t = 'program_studi';
$cfg = $tables[$t];
$canWrite = can('master.write');

$errors = [];
$editId = (int)($_GET['edit'] ?? 0);
$form = ['nama' => '', 'parent_id' => ''];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_perm('master.write');
    csrf_verify();
    if (($_POST['action'] ?? '') === 'delete') {
        $msg = master_delete($t, (int)($_POST['id'] ?? 0));
        $msg ? flash_set('error', $msg) : flash_set('success', 'Data dihapus.');
        redirect('master.php?t=' . urlencode($t));
    }
    $id = (int)($_POST['id'] ?? 0) ?: null;
    [$errors, $clean] = master_validate($t, $_POST, $id);
    if (!$errors) {
        try {
            master_save($t, $id, $clean);
            flash_set('success', 'Data tersimpan.');
            redirect('master.php?t=' . urlencode($t));
        } catch (PDOException $e) {
            error_log($e->getMessage());
            $errors['nama'] = 'Gagal menyimpan (kemungkinan nama sudah ada).';
        }
    }
    $form = ['nama' => $_POST['nama'] ?? '', 'parent_id' => $_POST['parent_id'] ?? ''];
    $editId = $id ?? 0;
} elseif ($editId) {
    $r = master_find($t, $editId);
    if ($r) $form = ['nama' => $r['nama'], 'parent_id' => $r['parent_id'] ?? ''];
    else $editId = 0;
}

$rows = master_list($t);
$pageTitle = 'Master Data - ' . $cfg['label'];
$active = 'master';
include __DIR__ . '/includes/header.php';
?>
<div class="pagehead"><h1>Master Data</h1></div>
<div class="tabs no-print">
  <?php foreach ($tables as $key => $c): ?>
    <a href="master.php?t=<?= e($key) ?>" class="<?= $key === $t ? 'active' : '' ?>"><?= e($c['label']) ?></a>
  <?php endforeach; ?>
</div>

<?php if ($canWrite): ?>
<form method="post" class="card">
  <h3><?= $editId ? 'Ubah' : 'Tambah' ?> <?= e($cfg['label']) ?></h3>
  <?= csrf_field() ?>
  <input type="hidden" name="t" value="<?= e($t) ?>">
  <input type="hidden" name="id" value="<?= (int)$editId ?>">
  <div class="formgrid">
    <?php if ($cfg['parent']): ?>
    <div class="field"><label for="parent_id"><?= e($cfg['parent']['label']) ?> *</label>
      <select id="parent_id" name="parent_id"><option value="">- pilih -</option>
        <?php foreach (options($cfg['parent']['table']) as $k => $n): ?>
          <option value="<?= (int)$k ?>" <?= (string)$form['parent_id'] === (string)$k ? 'selected' : '' ?>><?= e($n) ?></option>
        <?php endforeach; ?>
      </select><?= isset($errors['parent_id']) ? '<small class="err">' . e($errors['parent_id']) . '</small>' : '' ?></div>
    <?php endif; ?>
    <div class="field"><label for="nama">Nama *</label>
      <input type="text" id="nama" name="nama" value="<?= e($form['nama']) ?>" required>
      <?= isset($errors['nama']) ? '<small class="err">' . e($errors['nama']) . '</small>' : '' ?></div>
  </div>
  <button class="btn" type="submit">Simpan</button>
  <?php if ($editId): ?><a class="btn btn-line" href="master.php?t=<?= e($t) ?>">Batal</a><?php endif; ?>
</form>
<?php endif; ?>

<div class="card">
  <h3>Daftar <?= e($cfg['label']) ?></h3>
  <div class="tablewrap"><table>
    <thead><tr><th>No</th><?php if ($cfg['parent']): ?><th><?= e($cfg['parent']['label']) ?></th><?php endif; ?><th>Nama</th><?php if ($canWrite): ?><th>Aksi</th><?php endif; ?></tr></thead>
    <tbody>
    <?php foreach ($rows as $i => $r): ?>
      <tr>
        <td><?= $i + 1 ?></td>
        <?php if ($cfg['parent']): ?><td><?= e($r['parent_nama'] ?? '-') ?></td><?php endif; ?>
        <td><?= e($r['nama']) ?></td>
        <?php if ($canWrite): ?>
        <td><div class="actions">
          <a class="btn btn-sm btn-line" href="master.php?t=<?= e($t) ?>&edit=<?= (int)$r['id'] ?>">Ubah</a>
          <form method="post" onsubmit="return confirm('Hapus data ini?');">
            <?= csrf_field() ?><input type="hidden" name="t" value="<?= e($t) ?>"><input type="hidden" name="action" value="delete"><input type="hidden" name="id" value="<?= (int)$r['id'] ?>">
            <button class="btn btn-sm btn-danger" type="submit">Hapus</button>
          </form></div></td>
        <?php endif; ?>
      </tr>
    <?php endforeach; ?>
    <?php if (!$rows): ?><tr><td colspan="4" class="muted">Belum ada data.</td></tr><?php endif; ?>
    </tbody>
  </table></div>
</div>
<?php include __DIR__ . '/includes/footer.php'; ?>
