<?php
// includes/auth.php - autentikasi (login/logout) + RBAC untuk halaman web
require_once __DIR__ . '/../koneksi.php';
require_once __DIR__ . '/helpers.php';
require_once __DIR__ . '/session.php';
require_once __DIR__ . '/csrf.php';

const MAX_LOGIN_FAIL = 5;
const LOCK_SECONDS   = 300;

function current_user(): ?array
{
    static $user = false;
    if ($user !== false) return $user;
    $user = null;
    if (!empty($_SESSION['uid'])) {
        $st = db()->prepare('SELECT id, username, nama_lengkap, role, is_active FROM users WHERE id = ?');
        $st->execute([$_SESSION['uid']]);
        $row = $st->fetch();
        if ($row && (int)$row['is_active'] === 1) {
            $user = $row;
        } else {
            unset($_SESSION['uid']);
        }
    }
    return $user;
}

function login_locked_seconds(): int
{
    return max(0, ($_SESSION['lock_until'] ?? 0) - time());
}

function login_attempt(string $username, string $password): bool
{
    if (login_locked_seconds() > 0) return false;

    $st = db()->prepare('SELECT id, password_hash FROM users WHERE username = ? AND is_active = 1');
    $st->execute([$username]);
    $row = $st->fetch();

    if ($row && password_verify($password, $row['password_hash'])) {
        session_regenerate_id(true);
        $_SESSION['uid'] = (int)$row['id'];
        unset($_SESSION['fail'], $_SESSION['lock_until']);
        if (password_needs_rehash($row['password_hash'], PASSWORD_DEFAULT)) {
            db()->prepare('UPDATE users SET password_hash = ? WHERE id = ?')
                ->execute([password_hash($password, PASSWORD_DEFAULT), $row['id']]);
        }
        return true;
    }

    $_SESSION['fail'] = ($_SESSION['fail'] ?? 0) + 1;
    if ($_SESSION['fail'] >= MAX_LOGIN_FAIL) {
        $_SESSION['lock_until'] = time() + LOCK_SECONDS;
        $_SESSION['fail'] = 0;
    }
    return false;
}

function logout_user(): void
{
    $_SESSION = [];
    if (ini_get('session.use_cookies')) {
        $p = session_get_cookie_params();
        setcookie(session_name(), '', time() - 42000, $p['path'], $p['domain'], $p['secure'], $p['httponly']);
    }
    session_destroy();
}

function can(string $perm): bool
{
    $u = current_user();
    return $u ? role_can($u['role'], $perm) : false;
}

function require_login(): array
{
    $u = current_user();
    if (!$u) redirect('login.php');
    return $u;
}

function require_perm(string $perm): array
{
    $u = require_login();
    if (!role_can($u['role'], $perm)) {
        http_response_code(403);
        $pageTitle = 'Akses ditolak';
        $active = '';
        include __DIR__ . '/header.php';
        echo '<div class="card"><h2>403 - Akses ditolak</h2><p>Role <strong>' . e($u['role']) . '</strong> tidak punya izin untuk halaman ini.</p>'
           . '<p><a class="btn" href="dashboard.php">Kembali ke dashboard</a></p></div>';
        include __DIR__ . '/footer.php';
        exit;
    }
    return $u;
}
