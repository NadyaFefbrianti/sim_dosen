-- =====================================================
-- SIM DOSEN UM BENGKULU - dump database
-- Import lewat phpMyAdmin (tab Import) atau: mysql -u root < dump_sim_dosen.sql
-- =====================================================
CREATE DATABASE IF NOT EXISTS simdosen CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE simdosen;

SET FOREIGN_KEY_CHECKS = 0;
DROP TABLE IF EXISTS api_tokens, dosen, program_studi, fakultas, universitas,
  jabatan_fungsional, kepangkatan, pendidikan, rumpun_ilmu, status_pegawai,
  ikatan_kerja, status_aktivitas, users;
SET FOREIGN_KEY_CHECKS = 1;

-- ---------- Autentikasi & RBAC ----------
CREATE TABLE users (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  username VARCHAR(50) NOT NULL UNIQUE,
  password_hash VARCHAR(255) NOT NULL,
  nama_lengkap VARCHAR(100) NOT NULL,
  role ENUM('admin','operator','viewer') NOT NULL DEFAULT 'viewer',
  is_active TINYINT(1) NOT NULL DEFAULT 1,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE api_tokens (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  user_id INT UNSIGNED NOT NULL,
  token_hash CHAR(64) NOT NULL UNIQUE,
  expires_at DATETIME NOT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_token_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ---------- Tabel master ----------
CREATE TABLE universitas (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  nama VARCHAR(150) NOT NULL UNIQUE
) ENGINE=InnoDB;

CREATE TABLE fakultas (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  universitas_id INT UNSIGNED NOT NULL,
  nama VARCHAR(150) NOT NULL,
  UNIQUE KEY uq_fakultas (universitas_id, nama),
  CONSTRAINT fk_fakultas_univ FOREIGN KEY (universitas_id) REFERENCES universitas(id)
) ENGINE=InnoDB;

CREATE TABLE program_studi (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  fakultas_id INT UNSIGNED NOT NULL,
  nama VARCHAR(150) NOT NULL,
  UNIQUE KEY uq_prodi (fakultas_id, nama),
  CONSTRAINT fk_prodi_fakultas FOREIGN KEY (fakultas_id) REFERENCES fakultas(id)
) ENGINE=InnoDB;

CREATE TABLE jabatan_fungsional (id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY, nama VARCHAR(100) NOT NULL UNIQUE) ENGINE=InnoDB;
CREATE TABLE kepangkatan        (id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY, nama VARCHAR(100) NOT NULL UNIQUE) ENGINE=InnoDB;
CREATE TABLE pendidikan         (id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY, nama VARCHAR(100) NOT NULL UNIQUE) ENGINE=InnoDB;
CREATE TABLE rumpun_ilmu        (id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY, nama VARCHAR(100) NOT NULL UNIQUE) ENGINE=InnoDB;
CREATE TABLE status_pegawai     (id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY, nama VARCHAR(100) NOT NULL UNIQUE) ENGINE=InnoDB;
CREATE TABLE ikatan_kerja       (id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY, nama VARCHAR(100) NOT NULL UNIQUE) ENGINE=InnoDB;
CREATE TABLE status_aktivitas   (id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY, nama VARCHAR(100) NOT NULL UNIQUE) ENGINE=InnoDB;

-- ---------- Tabel utama ----------
CREATE TABLE dosen (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  nomor_registrasi VARCHAR(30) NOT NULL UNIQUE,
  nuptk CHAR(16) NULL UNIQUE,
  nama VARCHAR(150) NOT NULL,
  nip VARCHAR(18) NULL UNIQUE,
  jabatan_fungsional_id INT UNSIGNED NULL,
  kepangkatan_id INT UNSIGNED NULL,
  pendidikan_id INT UNSIGNED NULL,
  rumpun_ilmu_id INT UNSIGNED NULL,
  status_serdos ENUM('Sudah','Belum') NOT NULL DEFAULT 'Belum',
  status_pegawai_id INT UNSIGNED NULL,
  ikatan_kerja_id INT UNSIGNED NULL,
  status_aktivitas_id INT UNSIGNED NULL,
  prodi_id INT UNSIGNED NULL,
  penempatan VARCHAR(150) NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX idx_dosen_nama (nama),
  CONSTRAINT fk_d_jabatan  FOREIGN KEY (jabatan_fungsional_id) REFERENCES jabatan_fungsional(id),
  CONSTRAINT fk_d_pangkat  FOREIGN KEY (kepangkatan_id)        REFERENCES kepangkatan(id),
  CONSTRAINT fk_d_pend     FOREIGN KEY (pendidikan_id)         REFERENCES pendidikan(id),
  CONSTRAINT fk_d_rumpun   FOREIGN KEY (rumpun_ilmu_id)        REFERENCES rumpun_ilmu(id),
  CONSTRAINT fk_d_spegawai FOREIGN KEY (status_pegawai_id)     REFERENCES status_pegawai(id),
  CONSTRAINT fk_d_ikatan   FOREIGN KEY (ikatan_kerja_id)       REFERENCES ikatan_kerja(id),
  CONSTRAINT fk_d_aktif    FOREIGN KEY (status_aktivitas_id)   REFERENCES status_aktivitas(id),
  CONSTRAINT fk_d_prodi    FOREIGN KEY (prodi_id)              REFERENCES program_studi(id)
) ENGINE=InnoDB;

-- ---------- Data awal ----------
INSERT INTO universitas (nama) VALUES ('Universitas Muhammadiyah Bengkulu');
INSERT INTO fakultas (universitas_id, nama) VALUES (1, 'Teknik');
INSERT INTO program_studi (fakultas_id, nama) VALUES
  (1,'Teknik Informatika'),(1,'Teknik Sipil'),(1,'Teknik Elektro'),(1,'Teknik Mesin');

INSERT INTO jabatan_fungsional (nama) VALUES ('Tenaga Pengajar'),('Asisten Ahli'),('Lektor'),('Lektor Kepala'),('Guru Besar');
INSERT INTO kepangkatan (nama) VALUES
  ('Penata Muda (III/a)'),('Penata Muda Tk.I (III/b)'),('Penata (III/c)'),('Penata Tk.I (III/d)'),
  ('Pembina (IV/a)'),('Pembina Tk.I (IV/b)'),('Pembina Utama Muda (IV/c)');
INSERT INTO pendidikan (nama) VALUES ('S1'),('S2'),('S3'),('Profesi');
INSERT INTO rumpun_ilmu (nama) VALUES ('Ilmu Komputer'),('Teknik Sipil'),('Teknik Elektro'),('Teknik Mesin'),('Sistem Informasi');
INSERT INTO status_pegawai (nama) VALUES ('Dosen Tetap Yayasan'),('Dosen Tidak Tetap'),('PNS DPK');
INSERT INTO ikatan_kerja (nama) VALUES ('Dosen Tetap'),('Dosen Tidak Tetap'),('Dosen LB');
INSERT INTO status_aktivitas (nama) VALUES ('Aktif'),('Tugas Belajar'),('Cuti'),('Izin Belajar'),('Pensiun');

-- Data dosen CONTOH (fiktif) - ganti/hapus dengan data asli
INSERT INTO dosen (nomor_registrasi,nuptk,nama,nip,jabatan_fungsional_id,kepangkatan_id,pendidikan_id,rumpun_ilmu_id,status_serdos,status_pegawai_id,ikatan_kerja_id,status_aktivitas_id,prodi_id,penempatan) VALUES
 ('REG-0001','1234567890123401','Dosen Contoh Satu, M.Kom.',NULL,3,3,2,1,'Sudah',1,1,1,1,'Universitas Muhammadiyah Bengkulu'),
 ('REG-0002','1234567890123402','Dosen Contoh Dua, M.T.','198001012005011001',4,5,3,1,'Sudah',3,1,1,1,'Universitas Muhammadiyah Bengkulu'),
 ('REG-0003','1234567890123403','Dosen Contoh Tiga, M.Cs.',NULL,2,2,2,5,'Belum',1,1,1,1,'Universitas Muhammadiyah Bengkulu'),
 ('REG-0004',NULL,'Dosen Contoh Empat, S.T., M.T.',NULL,1,NULL,2,2,'Belum',2,2,3,2,'Universitas Muhammadiyah Bengkulu'),
 ('REG-0005','1234567890123405','Dosen Contoh Lima, Ph.D.',NULL,3,4,3,3,'Sudah',1,1,2,3,'Universitas Muhammadiyah Bengkulu');
