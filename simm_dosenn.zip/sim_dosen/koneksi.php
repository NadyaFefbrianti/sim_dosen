<?php
// ============================================================
// koneksi.php - konfigurasi database (sesuaikan dengan XAMPP/hosting)
// ============================================================
const DB_HOST = 'sql102.infinityfree.com';
const DB_PORT = 3306;
const DB_NAME = 'if0_42293398_simdosen';
const DB_USER = 'if0_42293398';   // default XAMPP
const DB_PASS = 'QIUyYYBh6b2';       // default XAMPP kosong
const APP_NAME = 'SIM Dosen UM Bengkulu';

function db(): PDO
{
    static $pdo = null;
    if ($pdo === null) {
        $dsn = 'mysql:host=' . DB_HOST . ';port=' . DB_PORT . ';dbname=' . DB_NAME . ';charset=utf8mb4';
        try {
            $pdo = new PDO($dsn, DB_USER, DB_PASS, [
                PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES   => false,
            ]);
        } catch (PDOException $e) {
    error_log('Koneksi DB gagal: ' . $e->getMessage());
    http_response_code(500);
    exit('Gagal koneksi database. Periksa Error Logs di InfinityFree.');
    }
    return $pdo;
}
