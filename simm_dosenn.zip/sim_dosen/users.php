<?php
// users.php - manajemen pengguna & role (khusus admin)
require_once __DIR__ . '/includes/auth.php';
$me = require_perm('users.manage');

const ROLES = ['admin', 'operator', 'viewer'];
$errors = [];
$editId = (int)($_GET['edit'] ?? 0);
$form = ['username' => '', 'nama_lengkap' => '', 'role' => 'viewer', 'is_active' => 1];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();
    $action = $_POST['action'] ?? 'save';

    if ($action === 'delete') {
        $id = (int)($_POST['id'] ?? 0);
        if ($id === (int)$me['id']) flash_set('error', 'Kamu tidak bisa menghapus akunmu sendiri.');
        else { db()->prepare('DELETE FROM users WHERE id = ?')->execute([$id]); flash_set('success', 'Pengguna dihapus.'); }
        redirect('users.php');
    }

    $id = (int)($_POST['id'] ?? 0);
    $in = [
        'username'     => trim((string)($_POST['username'] ?? '')),
        'nama_lengkap' => trim((string)($_POST['nama_lengkap'] ?? '')),
        'role'         => (string)($_POST['role'] ?? ''),
        'is_active'    => isset($_POST['is_active']) ? 1 : 0,
    ];
    $pass = (string)($_POST['password'] ?? '');
    $self = $id === (int)$me['id'];

    if (!preg_match('/^[A-Za-z0-9_.-]{3,50}$/', $in['username'])) $errors['username'] = 'Username 3-50 karakter: huruf, angka, titik, strip, underscore.';
    if ($in['nama_lengkap'] === '' || mb_strlen($in['nama_lengkap']) > 100) $errors['nama_lengkap'] = 'Nama wajib diisi (maks 100 karakter).';
    if (!in_array($in['role'], ROLES, true)) $errors['role'] = 'Role tidak valid.';
    if (!$id && strlen($pass) < 8) $errors['password'] = 'Password minimal 8 karakter.';
    if ($id && $pass !== '' && strlen($pass) < 8) $errors['password'] = 'Password baru minimal 8 karakter.';
    if ($self) { $in['role'] = 'admin'; $in['is_active'] = 1; } // cegah admin mengunci dirinya sendiri

    if (!isset($errors['username'])) {
        $st = db()->prepare('SELECT id FROM users WHERE username = ? AND id <> ?');
        $st->execute([$in['username'], $id]);
        if ($st->fetch()) $errors['username'] = 'Username sudah dipakai.';
    }

    if (!$errors) {
        if ($id) {
            db()->prepare('UPDATE users SET username=?, nama_lengkap=?, role=?, is_active=? WHERE id=?')
                ->execute([$in['username'], $in['nama_lengkap'], $in['role'], $in['is_active'], $id]);
            if ($pass !== '') {
                db()->prepare('UPDATE users SET password_hash=? WHERE id=?')->execute([password_hash($pass, PASSWORD_DEFAULT), $id]);
                db()->prepare('DELETE FROM api_tokens WHERE user_id=?')->execute([$id]); // cabut token lama
            }
            flash_set('success', 'Pengguna diperbarui.');
        } else {
            db()->prepare('INSERT INTO users (username, password_hash, nama_lengkap, role, is_active) VALUES (?,?,?,?,?)')
                ->execute([$in['username'], password_hash($pass, PASSWORD_DEFAULT), $in['nama_lengkap'], $in['role'], $in['is_active']]);
            flash_set('success', 'Pengguna ditambahkan.');
        }
        redirect('users.php');
    }
    $form = $in;
    $editId = $id;
} elseif ($editId) {
    $st = db()->prepare('SELECT id, username, nama_lengkap, role, is_active FROM users WHERE id = ?');
    $st->execute([$editId]);
    $r = $st->fetch();
    if ($r) $form = $r; else $editId = 0;
}

$users = db()->query('SELECT id, username, nama_lengkap, role, is_active, created_at FROM users ORDER BY username')->fetchAll();
$pageTitle = 'Pengguna';
$active = 'users';
include __DIR__ . '/includes/header.php';
?>
<div class="pagehead"><h1>Pengguna &amp; Role</h1></div>

<form method="post" class="card" autocomplete="off">
  <h3><?= $editId ? 'Ubah pengguna' : 'Tambah pengguna' ?></h3>
  <?= csrf_field() ?><input type="hidden" name="id" value="<?= (int)$editId ?>">
  <div class="formgrid">
    <div class="field"><label for="username">Username *</label>
      <input type="text" id="username" name="username" value="<?= e($form['username']) ?>" required>
      <?= isset($errors['username']) ? '<small class="err">' . e($errors['username']) . '</small>' : '' ?></div>
    <div class="field"><label for="nama_lengkap">Nama lengkap *</label>
      <input type="text" id="nama_lengkap" name="nama_lengkap" value="<?= e($form['nama_lengkap']) ?>" required>
      <?= isset($errors['nama_lengkap']) ? '<small class="err">' . e($errors['nama_lengkap']) . '</small>' : '' ?></div>
    <div class="field"><label for="role">Role *</label>
      <select id="role" name="role">
        <?php foreach (ROLES as $r): ?><option <?= $form['role'] === $r ? 'selected' : '' ?>><?= $r ?></option><?php endforeach; ?>
      </select><?= isset($errors['role']) ? '<small class="err">' . e($errors['role']) . '</small>' : '' ?></div>
    <div class="field"><label for="password">Password <?= $editId ? '(kosongkan jika tidak diganti)' : '*' ?></label>
      <input type="password" id="password" name="password">
      <?= isset($errors['password']) ? '<small class="err">' . e($errors['password']) . '</small>' : '' ?></div>
  </div>
  <div class="field"><label><input type="checkbox" name="is_active" value="1" <?= (int)$form['is_active'] ? 'checked' : '' ?>> Akun aktif</label></div>
  <button class="btn" type="submit">Simpan</button>
  <?php if ($editId): ?><a class="btn btn-line" href="users.php">Batal</a><?php endif; ?>
  <p class="muted">admin: semua akses &middot; operator: kelola data dosen &amp; master, lihat laporan &middot; viewer: hanya melihat.</p>
</form>

<div class="card"><div class="tablewrap"><table>
  <thead><tr><th>Username</th><th>Nama</th><th>Role</th><th>Status</th><th>Dibuat</th><th>Aksi</th></tr></thead>
  <tbody>
  <?php foreach ($users as $u): ?>
    <tr>
      <td><?= e($u['username']) ?></td><td><?= e($u['nama_lengkap']) ?></td><td><span class="badge"><?= e($u['role']) ?></span></td>
      <td><?= $u['is_active'] ? 'Aktif' : 'Nonaktif' ?></td><td class="nowrap"><?= e($u['created_at']) ?></td>
      <td><div class="actions">
        <a class="btn btn-sm btn-line" href="users.php?edit=<?= (int)$u['id'] ?>">Ubah</a>
        <?php if ((int)$u['id'] !== (int)$me['id']): ?>
        <form method="post" onsubmit="return confirm('Hapus pengguna ini?');">
          <?= csrf_field() ?><input type="hidden" name="action" value="delete"><input type="hidden" name="id" value="<?= (int)$u['id'] ?>">
          <button class="btn btn-sm btn-danger" type="submit">Hapus</button>
        </form>
        <?php endif; ?>
      </div></td>
    </tr>
  <?php endforeach; ?>
  </tbody>
</table></div></div>
<?php include __DIR__ . '/includes/footer.php'; ?>
