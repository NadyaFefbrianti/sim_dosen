
<?php
ini_set('display_errors', '0');
error_reporting(E_ALL);

require_once __DIR__ . '/includes/auth.php';

try {
    $sql = "SELECT d.nama, jf.nama AS jabatan,
                   pd.nama AS pend, sa.nama AS aktif,
                   d.status_serdos
            FROM dosen d
            LEFT JOIN jabatan_fungsional jf
                ON jf.id = d.jabatan_fungsional_id
            LEFT JOIN pendidikan pd
                ON pd.id = d.pendidikan_id
            LEFT JOIN status_aktivitas sa
                ON sa.id = d.status_aktivitas_id
            ORDER BY d.id DESC
            LIMIT 5";

    $rows = db()->query($sql)->fetchAll();

    echo "QUERY DOSEN BERHASIL<br>";
    echo "Jumlah data: " . count($rows);
} catch (Throwable $e) {
    error_log('Query dosen gagal: ' . $e->getMessage());

    echo "QUERY DOSEN GAGAL<br>";
    echo "Jenis error: "
        . htmlspecialchars(get_class($e));
    echo "<br>Kode error: "
        . htmlspecialchars((string) $e->getCode());
    echo "<br>Pesan: "
        . htmlspecialchars($e->getMessage());
}
