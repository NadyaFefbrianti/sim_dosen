<?php
// setupadminsimdosen.php - membuat akun ADMIN PERTAMA.
// Hanya bisa dipakai kalau belum ada admin di tabel users.
// SETELAH BERHASIL: HAPUS file ini dari server!
require_once __DIR__ . '/includes/auth.php';

$adaAdmin = (int)db()->query("SELECT COUNT(*) FROM users WHERE role = 'admin'")->fetchColumn() > 0;
$errors = [];
$done = false;
$in = ['username' => '', 'nama_lengkap' => ''];

if (!$adaAdmin && $_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();
    $in['username'] = trim((string)($_POST['username'] ?? ''));
    $in['nama_lengkap'] = trim((string)($_POST['nama_lengkap'] ?? ''));
    $pass = (string)($_POST['password'] ?? '');
    $pass2 = (string)($_POST['password2'] ?? '');

    if (!preg_match('/^[A-Za-z0-9_.-]{3,50}$/', $in['username'])) $errors[] = 'Username 3-50 karakter: huruf, angka, titik, strip, atau underscore.';
    if ($in['nama_lengkap'] === '' || mb_strlen($in['nama_lengkap']) > 100) $errors[] = 'Nama lengkap wajib diisi (maks 100 karakter).';
    if (strlen($pass) < 8) $errors[] = 'Password minimal 8 karakter.';
    if ($pass !== $pass2) $errors[] = 'Konfirmasi password tidak sama.';

    if (!$errors) {
        db()->prepare("INSERT INTO users (username, password_hash, nama_lengkap, role) VALUES (?, ?, ?, 'admin')")
            ->execute([$in['username'], password_hash($pass, PASSWORD_DEFAULT), $in['nama_lengkap']]);
        $done = true;
        $adaAdmin = true;
    }
}
?><!DOCTYPE html>
<html lang="id">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Setup Admin - <?= e(APP_NAME) ?></title>
<link rel="stylesheet" href="assets/style.css">
</head>
<body class="auth">
<div class="authbox">
  <div class="card">
    <h1>Setup admin pertama</h1>
    <?php if ($done): ?>
      <div class="alert alert-success">Akun admin berhasil dibuat.</div>
      <div class="alert alert-warn"><strong>Penting:</strong> hapus file <code>setupadminsimdosen.php</code> dari folder aplikasi sekarang juga.</div>
      <a class="btn" href="login.php">Lanjut ke login</a>
    <?php elseif ($adaAdmin): ?>
      <div class="alert alert-warn">Admin sudah ada, jadi halaman ini dikunci. Hapus file <code>setupadminsimdosen.php</code> dari server.</div>
      <a class="btn" href="login.php">Ke halaman login</a>
    <?php else: ?>
      <p class="muted">Buat akun admin untuk pertama kali.</p>
      <?php foreach ($errors as $m): ?><div class="alert alert-error"><?= e($m) ?></div><?php endforeach; ?>
      <form method="post" autocomplete="off">
        <?= csrf_field() ?>
        <div class="field"><label for="nama_lengkap">Nama lengkap</label>
          <input type="text" id="nama_lengkap" name="nama_lengkap" value="<?= e($in['nama_lengkap']) ?>" required></div>
        <div class="field"><label for="username">Username</label>
          <input type="text" id="username" name="username" value="<?= e($in['username']) ?>" required></div>
        <div class="field"><label for="password">Password (min. 8 karakter)</label>
          <input type="password" id="password" name="password" required></div>
        <div class="field"><label for="password2">Ulangi password</label>
          <input type="password" id="password2" name="password2" required></div>
        <button class="btn" type="submit">Buat admin</button>
      </form>
    <?php endif; ?>
  </div>
</div>
</body>
</html>
