# SIM Dosen UM Bengkulu

Aplikasi web tradisional (PHP + MySQL) dan web service/API (JSON) untuk manajemen dosen.
Dibuat dengan PHP 8.1+ (PDO), tanpa framework. Sudah diuji di PHP 8.3 + MariaDB 10.11.

## Struktur file
```
simdosen/
├── index.php                  Landing page (publik)
├── login.php / logout.php     Login & logout
├── setupadminsimdosen.php     Membuat admin pertama (HAPUS setelah dipakai)
├── koneksi.php                Konfigurasi database (PDO)
├── dump_sim_dosen.sql         Struktur tabel + data awal
├── dashboard.php              Ringkasan statistik
├── dosen.php / dosen_form.php CRUD dosen (cari, filter, paginasi)
├── master.php                 CRUD 10 tabel master (universitas, fakultas, prodi, jabatan, dst)
├── users.php                  Kelola pengguna & role (admin saja)
├── laporan.php                Laporan daftar dosen (cetak)
├── laporan_export.php         Unduh laporan CSV
├── assets/style.css
├── includes/
│   ├── session.php            Session aman + timeout 30 menit
│   ├── csrf.php               Token CSRF
│   ├── helpers.php            Fungsi bantu + peta RBAC + konfigurasi tabel master
│   ├── auth.php               Login/logout, require_login, require_perm (RBAC)
│   ├── api_auth.php           Autentikasi token Bearer untuk API
│   ├── dosen_model.php        Query & validasi dosen (dipakai web dan API)
│   ├── master_model.php       Query & validasi tabel master
│   └── header.php / footer.php
└── api/
    ├── index.php  login.php  logout.php  dosen.php  master.php  stats.php  .htaccess
```

## Langkah 1 - Siapkan XAMPP
1. Install XAMPP (PHP 8.1 atau lebih baru).
2. Buka XAMPP Control Panel, klik **Start** pada **Apache** dan **MySQL**.
3. Ekstrak ZIP ini, lalu pindahkan foldernya ke `C:\xampp\htdocs\` sehingga jadi `C:\xampp\htdocs\simdosen\`.

## Langkah 2 - Import database
1. Buka http://localhost/phpmyadmin
2. Klik tab **Import** > **Choose File** > pilih `dump_sim_dosen.sql` > **Import**.
   (Database `simdosen` dibuat otomatis oleh file SQL-nya.)
3. Pastikan database `simdosen` muncul di sebelah kiri dengan 13 tabel.

## Langkah 3 - Sambungkan aplikasi ke database
Buka `koneksi.php`. Untuk XAMPP bawaan tidak perlu diubah:
```php
const DB_HOST = '127.0.0.1';
const DB_NAME = 'simdosen';
const DB_USER = 'root';
const DB_PASS = '';
```
Kalau MySQL kamu pakai password atau port lain, sesuaikan di sini.

## Langkah 4 - Buat admin pertama
1. Buka http://localhost/simdosen/setupadminsimdosen.php
2. Isi nama, username, dan password (minimal 8 karakter) > **Buat admin**.
3. **Hapus file `setupadminsimdosen.php`** setelah berhasil (halaman ini otomatis terkunci kalau admin sudah ada, tapi tetap hapus).

## Langkah 5 - Coba aplikasinya
1. http://localhost/simdosen/ untuk landing page, lalu **Masuk ke sistem**.
2. Login dengan akun admin tadi.
3. Coba tiap menu: Dashboard, Data Dosen (tambah/ubah/hapus/cari), Master Data, Laporan (Cetak dan Unduh CSV), Pengguna.
4. Di menu **Pengguna**, buat akun `operator` dan `viewer`, lalu login dengan akun itu untuk melihat perbedaan hak akses.

| Role | Hak akses |
|---|---|
| admin | Semua, termasuk kelola pengguna |
| operator | Lihat + tambah/ubah/hapus dosen dan master, lihat laporan |
| viewer | Hanya melihat dosen, master, dan laporan |

## Langkah 6 - Coba web service (API)
Dokumentasi singkat: http://localhost/simdosen/api/index.php

Contoh dengan curl (di Windows pakai **Git Bash**, atau pakai Postman dengan isi yang sama):
```bash
# 1. Login, ambil token
curl -X POST http://localhost/simdosen/api/login.php -H "Content-Type: application/json" \
  -d '{"username":"admin","password":"PASSWORD_KAMU"}'

# 2. Pakai token (ganti TOKEN)
curl -H "Authorization: Bearer TOKEN" "http://localhost/simdosen/api/dosen.php?per_page=5"
curl -H "Authorization: Bearer TOKEN" "http://localhost/simdosen/api/dosen.php?id=1"

# 3. Tambah dosen
curl -X POST http://localhost/simdosen/api/dosen.php -H "Authorization: Bearer TOKEN" -H "Content-Type: application/json" \
  -d '{"nomor_registrasi":"API-001","nama":"Dosen API, M.Kom.","pendidikan_id":2,"prodi_id":1,"status_serdos":"Belum"}'

# 4. Ubah (boleh sebagian field) dan hapus
curl -X PUT "http://localhost/simdosen/api/dosen.php?id=6" -H "Authorization: Bearer TOKEN" -H "Content-Type: application/json" -d '{"nama":"Nama Baru"}'
curl -X DELETE "http://localhost/simdosen/api/dosen.php?id=6" -H "Authorization: Bearer TOKEN"

# 5. Master dan statistik
curl -H "Authorization: Bearer TOKEN" "http://localhost/simdosen/api/master.php?t=program_studi"
curl -H "Authorization: Bearer TOKEN" http://localhost/simdosen/api/stats.php
```
Kode respons: 200/201 berhasil, 401 token salah/kosong, 403 role tidak berhak, 404 tidak ditemukan, 422 validasi gagal.

## Langkah 7 - Upload ke GitHub
```bash
cd C:\xampp\htdocs\simdosen
git init
git add .
git commit -m "SIM Dosen UM Bengkulu: web tradisional + API"
git branch -M main
git remote add origin https://github.com/USERNAME_KAMU/simdosen.git
git push -u origin main
```
(Buat repository kosong `simdosen` di github.com dulu.) Ini jadi isian **URL GitHub file-file aplikasi**.

## Langkah 8 - Screenshot untuk isian "URL Tampilan Gambar Aplikasi dan Modul-Modulnya"
Ambil screenshot: landing page, login, dashboard, data dosen, form dosen, master data, pengguna, laporan, dan hasil API di Postman.
Gabungkan di satu folder Google Drive / Google Docs (akses "Siapa saja yang memiliki link"), lalu tempel link-nya.

## Langkah 9 - Hosting demo (isian "URL Hosting demo")
1. Daftar di layanan hosting PHP + MySQL gratis (misalnya InfinityFree), buat satu database MySQL.
2. Di phpMyAdmin hosting, buka `dump_sim_dosen.sql` di Notepad dulu dan **hapus 2 baris** `CREATE DATABASE ...` dan `USE simdosen;` di bagian atas (di hosting nama database sudah ditentukan), baru Import.
3. Edit `koneksi.php` sesuai host, nama database, user, dan password dari hosting.
4. Upload semua file ke folder `htdocs` hosting (File Manager atau FTP).
5. Buka `https://domainkamu/setupadminsimdosen.php`, buat admin, lalu **hapus file itu dari hosting**.
6. Jangan push password database hosting ke GitHub (ubah `koneksi.php` hanya di server).

## Keamanan yang sudah ada
Password di-hash (`password_hash`), semua query pakai prepared statement (PDO), output di-escape (`e()`) untuk mencegah XSS,
form pakai token CSRF, session `HttpOnly` + `SameSite` + regenerate saat login + timeout 30 menit, login dikunci 5 menit setelah 5x gagal,
logout lewat POST, token API disimpan sebagai hash SHA-256 dan kedaluwarsa 8 jam, CSV dilindungi dari formula injection.
