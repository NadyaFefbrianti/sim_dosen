<?php
// laporan_export.php - unduh laporan sebagai CSV (bisa dibuka di Excel)
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/dosen_model.php';
require_perm('laporan.read');

$rows = dosen_list(dosen_filters($_GET), 5000, 0);

// Cegah CSV/formula injection di Excel
$safe = function ($v): string {
    $v = (string)($v ?? '');
    return ($v !== '' && strpos("=+-@\t\r", $v[0]) !== false) ? "'" . $v : $v;
};

header('Content-Type: text/csv; charset=utf-8');
header('Content-Disposition: attachment; filename="daftar_dosen_' . date('Ymd_His') . '.csv"');
$out = fopen('php://output', 'w');
fwrite($out, "\xEF\xBB\xBF"); // BOM agar Excel membaca UTF-8
fputcsv($out, ['No', 'Nomor Registrasi', 'NUPTK', 'Nama', 'NIP', 'Jabatan Fungsional', 'Kepangkatan', 'Pendidikan Terakhir', 'Rumpun Ilmu',
               'Status Serdos', 'Status Pegawai', 'Ikatan Kerja', 'Status Aktivitas', 'Penempatan']);
foreach ($rows as $i => $d) {
    fputcsv($out, array_map($safe, [$i + 1, $d['nomor_registrasi'], $d['nuptk'], $d['nama'], $d['nip'], $d['jabatan_fungsional'], $d['kepangkatan'],
        $d['pendidikan'], $d['rumpun_ilmu'], $d['status_serdos'], $d['status_pegawai'], $d['ikatan_kerja'], $d['status_aktivitas'], $d['penempatan']]));
}
fclose($out);
