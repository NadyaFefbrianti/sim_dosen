<?php
// dashboard.php - ringkasan data (semua role yang login)
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/dosen_model.php';
$user = require_login();

$stats = stats_summary();
$groups = [
    'Jabatan fungsional' => stats_group('jabatan_fungsional', 'jabatan_fungsional_id'),
    'Pendidikan terakhir' => stats_group('pendidikan', 'pendidikan_id'),
    'Status aktivitas'    => stats_group('status_aktivitas', 'status_aktivitas_id'),
    'Status pegawai'      => stats_group('status_pegawai', 'status_pegawai_id'),
];
$terbaru = db()->query(dosen_base_sql() . ' ORDER BY d.id DESC LIMIT 5')->fetchAll();

$pageTitle = 'Dashboard';
$active = 'dashboard';
include __DIR__ . '/includes/header.php';
?>
<div class="pagehead">
  <h1>Dashboard</h1>
  <?php if (can('dosen.write')): ?><a class="btn" href="dosen_form.php">Tambah dosen</a><?php endif; ?>
</div>
<p class="muted">Halo, <?= e($user['nama_lengkap']) ?>. Berikut ringkasan data dosen saat ini.</p>

<div class="grid g4">
  <div class="card stat"><b><?= (int)$stats['total_dosen'] ?></b><span>total dosen</span></div>
  <div class="card stat"><b><?= (int)$stats['dosen_aktif'] ?></b><span>dosen aktif</span></div>
  <div class="card stat"><b><?= (int)$stats['sudah_serdos'] ?></b><span>sudah serdos</span></div>
  <div class="card stat"><b><?= (int)$stats['total_prodi'] ?></b><span>program studi</span></div>
</div>

<div class="grid g2">
<?php foreach ($groups as $judul => $rows): $max = max(1, ...array_map(fn($r) => (int)$r['total'], $rows ?: [['total' => 1]])); ?>
  <div class="card">
    <h3>Dosen per <?= e(strtolower($judul)) ?></h3>
    <ul class="rekap">
      <?php foreach ($rows as $r): ?>
        <li><span><?= e($r['label']) ?></span>
            <div class="bar2"><i style="width:<?= round($r['total'] / $max * 100) ?>%"></i></div>
            <b><?= (int)$r['total'] ?></b></li>
      <?php endforeach; ?>
      <?php if (!$rows): ?><li class="muted">Belum ada data.</li><?php endif; ?>
    </ul>
  </div>
<?php endforeach; ?>
</div>

<div class="card">
  <h3>Dosen yang baru ditambahkan</h3>
  <div class="tablewrap"><table>
    <thead><tr><th>Nama</th><th>Nomor Registrasi</th><th>Program Studi</th><th>Status Aktivitas</th></tr></thead>
    <tbody>
    <?php foreach ($terbaru as $d): ?>
      <tr><td><?= e($d['nama']) ?></td><td><?= e($d['nomor_registrasi']) ?></td><td><?= e($d['program_studi'] ?? '-') ?></td><td><?= e($d['status_aktivitas'] ?? '-') ?></td></tr>
    <?php endforeach; ?>
    <?php if (!$terbaru): ?><tr><td colspan="4" class="muted">Belum ada data dosen.</td></tr><?php endif; ?>
    </tbody>
  </table></div>
</div>
<?php include __DIR__ . '/includes/footer.php'; ?>
