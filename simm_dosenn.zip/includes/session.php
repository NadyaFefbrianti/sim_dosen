<?php
// includes/session.php - session aman + timeout idle 30 menit
if (session_status() === PHP_SESSION_NONE) {
    session_name('SIMDOSENSESS');
    session_set_cookie_params([
        'lifetime' => 0,
        'path'     => '/',
        'httponly' => true,
        'samesite' => 'Lax',
        'secure'   => !empty($_SERVER['HTTPS']),
    ]);
    ini_set('session.use_strict_mode', '1');
    session_start();
}

const SESSION_IDLE_LIMIT = 1800; // detik
if (isset($_SESSION['last_activity']) && (time() - $_SESSION['last_activity']) > SESSION_IDLE_LIMIT) {
    session_unset();
    session_destroy();
    session_start();
    $_SESSION['flash'][] = ['type' => 'warn', 'msg' => 'Sesi berakhir karena tidak ada aktivitas. Silakan login lagi.'];
}
$_SESSION['last_activity'] = time();
