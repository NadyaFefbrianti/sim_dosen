<?php
// includes/api_auth.php - bootstrap web service: JSON, token Bearer, RBAC
require_once __DIR__ . '/../koneksi.php';
require_once __DIR__ . '/helpers.php';

header('Content-Type: application/json; charset=utf-8');
header('X-Content-Type-Options: nosniff');

set_exception_handler(function (Throwable $e) {
    error_log('API error: ' . $e->getMessage());
    json_out(['error' => 'Terjadi kesalahan pada server.'], 500);
});

function api_method(): string { return strtoupper($_SERVER['REQUEST_METHOD'] ?? 'GET'); }

function api_input(): array
{
    $raw = file_get_contents('php://input');
    if ($raw === '' || $raw === false) return $_POST;
    $d = json_decode($raw, true);
    if (!is_array($d)) json_out(['error' => 'Body harus berupa JSON yang valid.'], 400);
    return $d;
}

function bearer_token(): ?string
{
    $h = $_SERVER['HTTP_AUTHORIZATION'] ?? $_SERVER['REDIRECT_HTTP_AUTHORIZATION'] ?? '';
    if ($h === '' && function_exists('getallheaders')) {
        foreach (getallheaders() as $k => $v) {
            if (strtolower($k) === 'authorization') $h = $v;
        }
    }
    return preg_match('/^Bearer\s+(\S+)$/i', $h, $m) ? $m[1] : null;
}

function api_user(): array
{
    $t = bearer_token();
    if (!$t) json_out(['error' => 'Token tidak ada. Login dulu lewat POST api/login.php.'], 401);
    $st = db()->prepare('SELECT u.id, u.username, u.nama_lengkap, u.role
                         FROM api_tokens t JOIN users u ON u.id = t.user_id
                         WHERE t.token_hash = ? AND t.expires_at > NOW() AND u.is_active = 1');
    $st->execute([hash('sha256', $t)]);
    $u = $st->fetch();
    if (!$u) json_out(['error' => 'Token tidak valid atau sudah kedaluwarsa.'], 401);
    return $u;
}

function api_require(string $perm): array
{
    $u = api_user();
    if (!role_can($u['role'], $perm)) json_out(['error' => 'Akses ditolak untuk role ' . $u['role'] . '.'], 403);
    return $u;
}
