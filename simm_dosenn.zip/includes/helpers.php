<?php
// includes/helpers.php - fungsi bantu umum (aman dipakai web & API)

function e($v): string { return htmlspecialchars((string)$v, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8'); }

function redirect(string $url): never { header('Location: ' . $url); exit; }

function flash_set(string $type, string $msg): void { $_SESSION['flash'][] = ['type' => $type, 'msg' => $msg]; }

function flash_render(): string
{
    $out = '';
    foreach ($_SESSION['flash'] ?? [] as $f) {
        $out .= '<div class="alert alert-' . e($f['type']) . '">' . e($f['msg']) . '</div>';
    }
    unset($_SESSION['flash']);
    return $out;
}

function null_if_empty($v): ?string
{
    if (!is_scalar($v)) return null;
    $v = trim((string)$v);
    return $v === '' ? null : $v;
}

function json_out($data, int $code = 200): never
{
    http_response_code($code);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT);
    exit;
}

/* ---------- RBAC: peta role -> permission ---------- */
const ROLE_PERMISSIONS = [
    'admin'    => ['*'],
    'operator' => ['dosen.read', 'dosen.write', 'master.read', 'master.write', 'laporan.read'],
    'viewer'   => ['dosen.read', 'master.read', 'laporan.read'],
];

function role_can(?string $role, string $perm): bool
{
    if (!$role || !isset(ROLE_PERMISSIONS[$role])) return false;
    $p = ROLE_PERMISSIONS[$role];
    return in_array('*', $p, true) || in_array($perm, $p, true);
}

/* ---------- Konfigurasi tabel master (whitelist) ---------- */
function master_tables(): array
{
    return [
        'universitas'        => ['label' => 'Universitas',         'parent' => null],
        'fakultas'           => ['label' => 'Fakultas',            'parent' => ['col' => 'universitas_id', 'table' => 'universitas', 'label' => 'Universitas']],
        'program_studi'      => ['label' => 'Program Studi',       'parent' => ['col' => 'fakultas_id',    'table' => 'fakultas',    'label' => 'Fakultas']],
        'jabatan_fungsional' => ['label' => 'Jabatan Fungsional',  'parent' => null],
        'kepangkatan'        => ['label' => 'Kepangkatan',         'parent' => null],
        'pendidikan'         => ['label' => 'Pendidikan Terakhir', 'parent' => null],
        'rumpun_ilmu'        => ['label' => 'Rumpun Ilmu',         'parent' => null],
        'status_pegawai'     => ['label' => 'Status Pegawai',      'parent' => null],
        'ikatan_kerja'       => ['label' => 'Ikatan Kerja',        'parent' => null],
        'status_aktivitas'   => ['label' => 'Status Aktivitas',    'parent' => null],
    ];
}

/** id => nama untuk dropdown. Nama tabel divalidasi lewat whitelist. */
function options(string $table): array
{
    if (!isset(master_tables()[$table])) throw new InvalidArgumentException('Tabel tidak valid');
    static $cache = [];
    if (!isset($cache[$table])) {
        $cache[$table] = db()->query("SELECT id, nama FROM `$table` ORDER BY nama")->fetchAll(PDO::FETCH_KEY_PAIR);
    }
    return $cache[$table];
}

/* ---------- Statistik untuk dashboard, landing, dan API ---------- */
function stats_summary(): array
{
    $pdo = db();
    $q = fn(string $sql): int => (int)$pdo->query($sql)->fetchColumn();
    return [
        'total_dosen'  => $q('SELECT COUNT(*) FROM dosen'),
        'dosen_aktif'  => $q("SELECT COUNT(*) FROM dosen d JOIN status_aktivitas s ON s.id = d.status_aktivitas_id WHERE s.nama = 'Aktif'"),
        'sudah_serdos' => $q("SELECT COUNT(*) FROM dosen WHERE status_serdos = 'Sudah'"),
        'total_prodi'  => $q('SELECT COUNT(*) FROM program_studi'),
    ];
}

/** Rekap jumlah dosen per master. $table & $fk selalu literal dari kode, bukan input user. */
function stats_group(string $table, string $fk): array
{
    $sql = "SELECT COALESCE(m.nama, '(Belum diisi)') AS label, COUNT(d.id) AS total
            FROM dosen d LEFT JOIN `$table` m ON m.id = d.`$fk`
            GROUP BY label ORDER BY total DESC, label";
    return db()->query($sql)->fetchAll();
}
