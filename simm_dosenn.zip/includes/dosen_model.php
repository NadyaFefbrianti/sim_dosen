<?php
// includes/dosen_model.php - logika data dosen (dipakai halaman web DAN API)

const DOSEN_FK = [
    'jabatan_fungsional_id' => 'jabatan_fungsional',
    'kepangkatan_id'        => 'kepangkatan',
    'pendidikan_id'         => 'pendidikan',
    'rumpun_ilmu_id'        => 'rumpun_ilmu',
    'status_pegawai_id'     => 'status_pegawai',
    'ikatan_kerja_id'       => 'ikatan_kerja',
    'status_aktivitas_id'   => 'status_aktivitas',
    'prodi_id'              => 'program_studi',
];

function dosen_base_sql(): string
{
    return 'SELECT d.*, jf.nama AS jabatan_fungsional, kp.nama AS kepangkatan, pd.nama AS pendidikan,
                   ri.nama AS rumpun_ilmu, sp.nama AS status_pegawai, ik.nama AS ikatan_kerja,
                   sa.nama AS status_aktivitas, ps.nama AS program_studi, fk.nama AS fakultas, un.nama AS universitas
            FROM dosen d
            LEFT JOIN jabatan_fungsional jf ON jf.id = d.jabatan_fungsional_id
            LEFT JOIN kepangkatan kp        ON kp.id = d.kepangkatan_id
            LEFT JOIN pendidikan pd         ON pd.id = d.pendidikan_id
            LEFT JOIN rumpun_ilmu ri        ON ri.id = d.rumpun_ilmu_id
            LEFT JOIN status_pegawai sp     ON sp.id = d.status_pegawai_id
            LEFT JOIN ikatan_kerja ik       ON ik.id = d.ikatan_kerja_id
            LEFT JOIN status_aktivitas sa   ON sa.id = d.status_aktivitas_id
            LEFT JOIN program_studi ps      ON ps.id = d.prodi_id
            LEFT JOIN fakultas fk           ON fk.id = ps.fakultas_id
            LEFT JOIN universitas un        ON un.id = fk.universitas_id ';
}

/** Bangun WHERE dari filter (q, prodi_id, status_aktivitas_id, pendidikan_id, status_serdos). */
function dosen_filters(array $src): array
{
    $w = [];
    $p = [];
    $q = trim((string)($src['q'] ?? ''));
    if ($q !== '') {
        $like = '%' . addcslashes($q, '%_\\') . '%';
        $w[] = '(d.nama LIKE :q1 OR d.nip LIKE :q2 OR d.nuptk LIKE :q3 OR d.nomor_registrasi LIKE :q4)';
        $p[':q1'] = $p[':q2'] = $p[':q3'] = $p[':q4'] = $like;
    }
    foreach (['prodi_id', 'status_aktivitas_id', 'pendidikan_id'] as $k) {
        $v = (int)($src[$k] ?? 0);
        if ($v > 0) { $w[] = "d.$k = :$k"; $p[":$k"] = $v; }
    }
    if (in_array($src['status_serdos'] ?? '', ['Sudah', 'Belum'], true)) {
        $w[] = 'd.status_serdos = :serdos';
        $p[':serdos'] = $src['status_serdos'];
    }
    return [$w ? 'WHERE ' . implode(' AND ', $w) : '', $p];
}

function dosen_count(array $f): int
{
    [$where, $params] = $f;
    $st = db()->prepare("SELECT COUNT(*) FROM dosen d $where");
    $st->execute($params);
    return (int)$st->fetchColumn();
}

function dosen_list(array $f, int $limit, int $offset): array
{
    [$where, $params] = $f;
    $sql = dosen_base_sql() . " $where ORDER BY d.nama ASC LIMIT " . (int)$limit . ' OFFSET ' . (int)$offset;
    $st = db()->prepare($sql);
    $st->execute($params);
    return $st->fetchAll();
}

function dosen_find(int $id): ?array
{
    $st = db()->prepare(dosen_base_sql() . ' WHERE d.id = ?');
    $st->execute([$id]);
    return $st->fetch() ?: null;
}

function dosen_raw(int $id): ?array
{
    $st = db()->prepare('SELECT * FROM dosen WHERE id = ?');
    $st->execute([$id]);
    return $st->fetch() ?: null;
}

/** Validasi + normalisasi input. Return [errors, clean]. */
function dosen_validate(array $in, ?int $id = null): array
{
    $err = [];
    $c = [];
    foreach (['nomor_registrasi', 'nuptk', 'nama', 'nip', 'penempatan'] as $k) {
        $c[$k] = null_if_empty($in[$k] ?? null);
    }

    if ($c['nomor_registrasi'] === null)            $err['nomor_registrasi'] = 'Nomor registrasi wajib diisi.';
    elseif (strlen($c['nomor_registrasi']) > 30)    $err['nomor_registrasi'] = 'Maksimal 30 karakter.';

    if ($c['nama'] === null)                        $err['nama'] = 'Nama wajib diisi.';
    elseif (mb_strlen($c['nama']) > 150)            $err['nama'] = 'Maksimal 150 karakter.';

    if ($c['nuptk'] !== null && !preg_match('/^\d{16}$/', $c['nuptk'])) $err['nuptk'] = 'NUPTK harus 16 digit angka.';
    if ($c['nip'] !== null && !preg_match('/^\d{18}$/', $c['nip']))     $err['nip']   = 'NIP harus 18 digit angka.';
    if ($c['penempatan'] !== null && mb_strlen($c['penempatan']) > 150) $err['penempatan'] = 'Maksimal 150 karakter.';

    $serdos = null_if_empty($in['status_serdos'] ?? null) ?? 'Belum';
    if (!in_array($serdos, ['Sudah', 'Belum'], true)) $err['status_serdos'] = 'Pilih Sudah atau Belum.';
    $c['status_serdos'] = $serdos;

    foreach (DOSEN_FK as $col => $tbl) {
        $v = null_if_empty($in[$col] ?? null);
        if ($v === null) { $c[$col] = null; continue; }
        if (!ctype_digit($v) || !isset(options($tbl)[(int)$v])) $err[$col] = 'Pilihan tidak valid.';
        else $c[$col] = (int)$v;
    }

    foreach (['nomor_registrasi', 'nuptk', 'nip'] as $k) {
        if ($c[$k] !== null && !isset($err[$k])) {
            $st = db()->prepare("SELECT id FROM dosen WHERE $k = ? AND id <> ?");
            $st->execute([$c[$k], $id ?? 0]);
            if ($st->fetch()) $err[$k] = 'Sudah dipakai dosen lain.';
        }
    }
    return [$err, $c];
}

function dosen_create(array $clean): int
{
    $cols = array_keys($clean); // kunci berasal dari dosen_validate (tetap), bukan dari user
    $sql = 'INSERT INTO dosen (' . implode(',', array_map(fn($c) => "`$c`", $cols)) . ') VALUES (' . implode(',', array_map(fn($c) => ":$c", $cols)) . ')';
    db()->prepare($sql)->execute($clean);
    return (int)db()->lastInsertId();
}

function dosen_update(int $id, array $clean): void
{
    $set = implode(', ', array_map(fn($c) => "`$c` = :$c", array_keys($clean)));
    $clean['__id'] = $id;
    db()->prepare("UPDATE dosen SET $set WHERE id = :__id")->execute($clean);
}

function dosen_delete(int $id): void
{
    db()->prepare('DELETE FROM dosen WHERE id = ?')->execute([$id]);
}
