<?php
// includes/master_model.php - logika tabel master (dipakai halaman web DAN API)

function master_cfg(string $t): array
{
    $all = master_tables();
    if (!isset($all[$t])) throw new InvalidArgumentException('Tabel master tidak dikenal');
    return $all[$t];
}

function master_list(string $t): array
{
    $cfg = master_cfg($t);
    if ($cfg['parent']) {
        $p = $cfg['parent'];
        $sql = "SELECT m.id, m.nama, m.`{$p['col']}` AS parent_id, p.nama AS parent_nama
                FROM `$t` m LEFT JOIN `{$p['table']}` p ON p.id = m.`{$p['col']}` ORDER BY p.nama, m.nama";
    } else {
        $sql = "SELECT id, nama FROM `$t` ORDER BY nama";
    }
    return db()->query($sql)->fetchAll();
}

function master_find(string $t, int $id): ?array
{
    $cfg = master_cfg($t);
    $col = $cfg['parent'] ? ", `{$cfg['parent']['col']}` AS parent_id" : '';
    $st = db()->prepare("SELECT id, nama $col FROM `$t` WHERE id = ?");
    $st->execute([$id]);
    return $st->fetch() ?: null;
}

function master_validate(string $t, array $in, ?int $id): array
{
    $cfg = master_cfg($t);
    $err = [];
    $c = ['nama' => null_if_empty($in['nama'] ?? null), 'parent_id' => null];

    if ($c['nama'] === null)              $err['nama'] = 'Nama wajib diisi.';
    elseif (mb_strlen($c['nama']) > 150)  $err['nama'] = 'Maksimal 150 karakter.';

    if ($cfg['parent']) {
        $pid = null_if_empty($in['parent_id'] ?? null);
        if ($pid === null || !ctype_digit($pid) || !isset(options($cfg['parent']['table'])[(int)$pid])) {
            $err['parent_id'] = $cfg['parent']['label'] . ' wajib dipilih.';
        } else {
            $c['parent_id'] = (int)$pid;
        }
    }

    if (!$err) {
        if ($cfg['parent']) {
            $st = db()->prepare("SELECT id FROM `$t` WHERE nama = ? AND `{$cfg['parent']['col']}` = ? AND id <> ?");
            $st->execute([$c['nama'], $c['parent_id'], $id ?? 0]);
        } else {
            $st = db()->prepare("SELECT id FROM `$t` WHERE nama = ? AND id <> ?");
            $st->execute([$c['nama'], $id ?? 0]);
        }
        if ($st->fetch()) $err['nama'] = 'Nama sudah ada.';
    }
    return [$err, $c];
}

function master_save(string $t, ?int $id, array $clean): int
{
    $cfg = master_cfg($t);
    if ($cfg['parent']) {
        $pc = $cfg['parent']['col'];
        if ($id) {
            db()->prepare("UPDATE `$t` SET nama = ?, `$pc` = ? WHERE id = ?")->execute([$clean['nama'], $clean['parent_id'], $id]);
            return $id;
        }
        db()->prepare("INSERT INTO `$t` (nama, `$pc`) VALUES (?, ?)")->execute([$clean['nama'], $clean['parent_id']]);
    } else {
        if ($id) {
            db()->prepare("UPDATE `$t` SET nama = ? WHERE id = ?")->execute([$clean['nama'], $id]);
            return $id;
        }
        db()->prepare("INSERT INTO `$t` (nama) VALUES (?)")->execute([$clean['nama']]);
    }
    return (int)db()->lastInsertId();
}

/** Return pesan error (string) bila gagal, null bila berhasil. */
function master_delete(string $t, int $id): ?string
{
    master_cfg($t);
    try {
        db()->prepare("DELETE FROM `$t` WHERE id = ?")->execute([$id]);
        return null;
    } catch (PDOException $e) {
        if ($e->getCode() === '23000') return 'Data tidak bisa dihapus karena masih dipakai data lain.';
        error_log($e->getMessage());
        return 'Gagal menghapus data.';
    }
}
