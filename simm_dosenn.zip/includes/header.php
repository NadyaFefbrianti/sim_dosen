<?php
// includes/header.php - layout atas (butuh $pageTitle, opsional $active)
$u = current_user();
$active = $active ?? '';
$nav = [
    ['dashboard', 'dashboard.php', 'Dashboard',   true],
    ['dosen',     'dosen.php',     'Data Dosen',  can('dosen.read')],
    ['master',    'master.php',    'Master Data', can('master.read')],
    ['laporan',   'laporan.php',   'Laporan',     can('laporan.read')],
    ['users',     'users.php',     'Pengguna',    can('users.manage')],
];
?><!DOCTYPE html>
<html lang="id">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title><?= e($pageTitle ?? 'SIM Dosen') ?> - <?= e(APP_NAME) ?></title>
<link rel="stylesheet" href="assets/style.css">
</head>
<body>
<header class="topbar no-print">
  <div class="container bar">
    <a class="brand" href="index.php"><?= e(APP_NAME) ?></a>
    <?php if ($u): ?>
    <nav class="nav">
      <?php foreach ($nav as [$key, $href, $label, $show]): if (!$show) continue; ?>
        <a href="<?= e($href) ?>" class="<?= $active === $key ? 'active' : '' ?>"><?= e($label) ?></a>
      <?php endforeach; ?>
    </nav>
    <form method="post" action="logout.php" class="logout">
      <?= csrf_field() ?>
      <span class="who"><?= e($u['nama_lengkap']) ?> (<?= e($u['role']) ?>)</span>
      <button class="btn btn-sm btn-light" type="submit">Keluar</button>
    </form>
    <?php endif; ?>
  </div>
</header>
<main class="container">
<?= flash_render() ?>
