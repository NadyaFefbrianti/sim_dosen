</main>
<footer class="foot no-print">
  <div class="container">&copy; <?= date('Y') ?> <?= e(APP_NAME) ?> &middot; Universitas Muhammadiyah Bengkulu</div>
</footer>
</body>
</html>
