<?php
// laporan.php - laporan daftar dosen (filter, cetak, unduh CSV)
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/dosen_model.php';
require_perm('laporan.read');

$f = dosen_filters($_GET);
$rows = dosen_list($f, 5000, 0);

// Kepala laporan: Universitas / Fakultas / Program Studi (seperti format Excel)
$ctx = ['universitas' => '-', 'fakultas' => 'Semua', 'prodi' => 'Semua'];
$pid = (int)($_GET['prodi_id'] ?? 0);
if ($pid > 0) {
    $st = db()->prepare('SELECT ps.nama AS prodi, fk.nama AS fakultas, un.nama AS universitas
                         FROM program_studi ps JOIN fakultas fk ON fk.id = ps.fakultas_id JOIN universitas un ON un.id = fk.universitas_id
                         WHERE ps.id = ?');
    $st->execute([$pid]);
    if ($c = $st->fetch()) {
        $ctx = ['universitas' => $c['universitas'], 'fakultas' => $c['fakultas'], 'prodi' => $c['prodi']];
    }
} else {
    $univ = options('universitas');
    $ctx['universitas'] = $univ ? reset($univ) : '-';
}
$aktifId = (int)($_GET['status_aktivitas_id'] ?? 0);
$judul = 'Daftar Dosen' . ($aktifId > 0 && isset(options('status_aktivitas')[$aktifId]) ? ' ' . options('status_aktivitas')[$aktifId] : '') . ' Universitas';

$pageTitle = 'Laporan Dosen';
$active = 'laporan';
include __DIR__ . '/includes/header.php';
?>
<div class="pagehead no-print"><h1>Laporan Dosen</h1>
  <div class="actions">
    <button class="btn" type="button" onclick="window.print()">Cetak</button>
    <a class="btn btn-line" href="laporan_export.php?<?= e(http_build_query($_GET)) ?>">Unduh CSV</a>
  </div>
</div>

<form method="get" class="card filters no-print">
  <div class="field"><label for="q">Cari</label><input type="search" id="q" name="q" value="<?= e($_GET['q'] ?? '') ?>"></div>
  <div class="field"><label for="prodi_id">Program studi</label>
    <select id="prodi_id" name="prodi_id"><option value="">Semua</option>
      <?php foreach (options('program_studi') as $id => $n): ?><option value="<?= $id ?>" <?= $pid === $id ? 'selected' : '' ?>><?= e($n) ?></option><?php endforeach; ?>
    </select></div>
  <div class="field"><label for="status_aktivitas_id">Status aktivitas</label>
    <select id="status_aktivitas_id" name="status_aktivitas_id"><option value="">Semua</option>
      <?php foreach (options('status_aktivitas') as $id => $n): ?><option value="<?= $id ?>" <?= $aktifId === $id ? 'selected' : '' ?>><?= e($n) ?></option><?php endforeach; ?>
    </select></div>
  <div class="field"><label for="status_serdos">Status serdos</label>
    <select id="status_serdos" name="status_serdos"><option value="">Semua</option>
      <?php foreach (['Sudah', 'Belum'] as $s): ?><option <?= ($_GET['status_serdos'] ?? '') === $s ? 'selected' : '' ?>><?= $s ?></option><?php endforeach; ?>
    </select></div>
  <div class="actions"><button class="btn" type="submit">Tampilkan</button><a class="btn btn-line" href="laporan.php">Reset</a></div>
</form>

<div class="card">
  <div class="report-head">
    <h2><?= e($judul) ?></h2>
    <div>Universitas : <?= e($ctx['universitas']) ?></div>
    <div>Fakultas : <?= e($ctx['fakultas']) ?></div>
    <div>Program Studi : <?= e($ctx['prodi']) ?></div>
    <div class="muted">Dicetak: <?= date('d-m-Y H:i') ?> &middot; Total: <?= count($rows) ?> dosen</div>
  </div>
  <div class="tablewrap"><table>
    <thead><tr>
      <th>No</th><th>Nomor Registrasi</th><th>NUPTK</th><th>Nama</th><th>NIP</th><th>Jabatan Fungsional</th><th>Kepangkatan</th>
      <th>Pendidikan Terakhir</th><th>Rumpun Ilmu</th><th>Status Serdos</th><th>Status Pegawai</th><th>Ikatan Kerja</th><th>Status Aktivitas</th><th>Penempatan</th>
    </tr></thead>
    <tbody>
    <?php foreach ($rows as $i => $d): ?>
      <tr><td><?= $i + 1 ?></td><td><?= e($d['nomor_registrasi']) ?></td><td><?= e($d['nuptk'] ?? '') ?></td><td><?= e($d['nama']) ?></td><td><?= e($d['nip'] ?? '') ?></td>
        <td><?= e($d['jabatan_fungsional'] ?? '') ?></td><td><?= e($d['kepangkatan'] ?? '') ?></td><td><?= e($d['pendidikan'] ?? '') ?></td><td><?= e($d['rumpun_ilmu'] ?? '') ?></td>
        <td><?= e($d['status_serdos']) ?></td><td><?= e($d['status_pegawai'] ?? '') ?></td><td><?= e($d['ikatan_kerja'] ?? '') ?></td><td><?= e($d['status_aktivitas'] ?? '') ?></td><td><?= e($d['penempatan'] ?? '') ?></td></tr>
    <?php endforeach; ?>
    <?php if (!$rows): ?><tr><td colspan="14" class="muted">Tidak ada data untuk filter ini.</td></tr><?php endif; ?>
    </tbody>
  </table></div>
</div>
<?php include __DIR__ . '/includes/footer.php'; ?>
