<?php
// dosen_form.php - tambah / ubah dosen
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/dosen_model.php';
require_perm('dosen.write');

$id = (int)($_GET['id'] ?? $_POST['id'] ?? 0);
$row = null;
if ($id) {
    $row = dosen_raw($id);
    if (!$row) { flash_set('error', 'Data dosen tidak ditemukan.'); redirect('dosen.php'); }
}

$errors = [];
$v = $row ?? ['nomor_registrasi' => '', 'nuptk' => '', 'nama' => '', 'nip' => '', 'status_serdos' => 'Belum', 'penempatan' => 'Universitas Muhammadiyah Bengkulu'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();
    [$errors, $clean] = dosen_validate($_POST, $id ?: null);
    $v = array_merge($v, $_POST);
    if (!$errors) {
        try {
            if ($id) { dosen_update($id, $clean); flash_set('success', 'Data dosen diperbarui.'); }
            else     { dosen_create($clean);      flash_set('success', 'Data dosen ditambahkan.'); }
            redirect('dosen.php');
        } catch (PDOException $e) {
            error_log($e->getMessage());
            $errors['_'] = 'Gagal menyimpan data. Coba lagi.';
        }
    }
}

function inp(string $name, string $label, array $v, array $err, bool $req = false, string $hint = ''): void
{
    echo '<div class="field"><label for="' . e($name) . '">' . e($label) . ($req ? ' *' : '') . '</label>'
       . '<input type="text" id="' . e($name) . '" name="' . e($name) . '" value="' . e($v[$name] ?? '') . '">'
       . ($hint ? '<small class="muted">' . e($hint) . '</small><br>' : '')
       . (isset($err[$name]) ? '<small class="err">' . e($err[$name]) . '</small>' : '') . '</div>';
}
function sel(string $name, string $label, array $opts, array $v, array $err): void
{
    echo '<div class="field"><label for="' . e($name) . '">' . e($label) . '</label><select id="' . e($name) . '" name="' . e($name) . '"><option value="">- pilih -</option>';
    foreach ($opts as $k => $t) {
        echo '<option value="' . (int)$k . '"' . ((string)($v[$name] ?? '') === (string)$k ? ' selected' : '') . '>' . e($t) . '</option>';
    }
    echo '</select>' . (isset($err[$name]) ? '<small class="err">' . e($err[$name]) . '</small>' : '') . '</div>';
}

$pageTitle = $id ? 'Ubah Dosen' : 'Tambah Dosen';
$active = 'dosen';
include __DIR__ . '/includes/header.php';
?>
<div class="pagehead"><h1><?= e($pageTitle) ?></h1><a class="btn btn-line" href="dosen.php">Kembali</a></div>
<?php if (isset($errors['_'])): ?><div class="alert alert-error"><?= e($errors['_']) ?></div><?php endif; ?>
<?php if ($errors && !isset($errors['_'])): ?><div class="alert alert-error">Ada isian yang perlu diperbaiki. Cek pesan di bawah kolom.</div><?php endif; ?>

<form method="post" class="card">
  <?= csrf_field() ?>
  <input type="hidden" name="id" value="<?= (int)$id ?>">
  <div class="formgrid">
    <?php inp('nomor_registrasi', 'Nomor Registrasi', $v, $errors, true); ?>
    <?php inp('nuptk', 'NUPTK', $v, $errors, false, '16 digit angka, boleh kosong'); ?>
    <?php inp('nama', 'Nama (beserta gelar)', $v, $errors, true); ?>
    <?php inp('nip', 'NIP', $v, $errors, false, '18 digit angka, boleh kosong'); ?>
    <?php sel('jabatan_fungsional_id', 'Jabatan Fungsional', options('jabatan_fungsional'), $v, $errors); ?>
    <?php sel('kepangkatan_id', 'Kepangkatan', options('kepangkatan'), $v, $errors); ?>
    <?php sel('pendidikan_id', 'Pendidikan Terakhir', options('pendidikan'), $v, $errors); ?>
    <?php sel('rumpun_ilmu_id', 'Rumpun Ilmu', options('rumpun_ilmu'), $v, $errors); ?>
    <div class="field"><label for="status_serdos">Status Serdos</label>
      <select id="status_serdos" name="status_serdos">
        <?php foreach (['Belum', 'Sudah'] as $s): ?><option <?= ($v['status_serdos'] ?? 'Belum') === $s ? 'selected' : '' ?>><?= $s ?></option><?php endforeach; ?>
      </select><?= isset($errors['status_serdos']) ? '<small class="err">' . e($errors['status_serdos']) . '</small>' : '' ?></div>
    <?php sel('status_pegawai_id', 'Status Pegawai', options('status_pegawai'), $v, $errors); ?>
    <?php sel('ikatan_kerja_id', 'Ikatan Kerja', options('ikatan_kerja'), $v, $errors); ?>
    <?php sel('status_aktivitas_id', 'Status Aktivitas', options('status_aktivitas'), $v, $errors); ?>
    <?php sel('prodi_id', 'Program Studi', options('program_studi'), $v, $errors); ?>
    <?php inp('penempatan', 'Penempatan', $v, $errors); ?>
  </div>
  <button class="btn" type="submit">Simpan</button>
  <a class="btn btn-line" href="dosen.php">Batal</a>
</form>
<?php include __DIR__ . '/includes/footer.php'; ?>
