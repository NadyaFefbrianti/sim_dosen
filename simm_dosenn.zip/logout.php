<?php
// logout.php - keluar (hanya lewat POST + token CSRF)
require_once __DIR__ . '/includes/auth.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') redirect('dashboard.php');
csrf_verify();
logout_user();
session_start();
flash_set('success', 'Kamu sudah keluar.');
redirect('login.php');
